# trader.app.executor package
from trader.app.executor.paper_executor import PaperExecutor

__all__ = ["PaperExecutor"]
