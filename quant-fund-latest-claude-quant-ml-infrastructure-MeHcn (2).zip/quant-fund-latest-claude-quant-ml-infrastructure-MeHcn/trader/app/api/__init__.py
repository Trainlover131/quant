# trader.app.api package
from trader.app.api.routes import router

__all__ = ["router"]
